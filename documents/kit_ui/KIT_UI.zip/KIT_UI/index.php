<!DOCTYPE html>
<html lang="fr">
    <head>
        
        <!-- liens + CDN -->
        
        <title>Kit UI</title>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="js/script.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        
    </head>
    
    <body data-spy="scroll" data-target="#myNavbar" data-offset="60">
        
        <!-- section pour navbar + glyphicon (animation) -->
        <section id="1"></section>
        
        
        
        
        
        <!-- titre -->
        
        <h1 id="kit">KIT UI- <a href="https://kfery.lyceestvincent.fr">kfery.lyceestvincent.fr</a></h1>
        
        
        
        
        <!-- TEXTES -->
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <!-- textes -->
                    <h2 class="kith2">Textes :</h2>
                    
                    <!-- titres -->
                    <h3 class="kith3">Titres :</h3>
                    
                    <div class="titre">
                        <h1>Titre principal</h1>
                        <h2>Titre des parties</h2>
                        <h3>Titre secondaire</h3>
                    </div>
                    
                    <!-- liens -->
                    <h3 class="kith3">Liens :</h3>
                    
                    <a href="" class="mailtoForm">Mailto</a>
                    <h5 class="hdoc"><strong>Exemple : </strong><a href="" target="">Liens</a></h5>
                    
                    <!-- messages -->
                    <h3 class="kith3">Messages :</h3>
                    
                    <p style="color:red; font-style:italic;">Message d'erreur</p>
                    <p class="remerciement">Message de remerciement</p>
                    
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- BOUTONS -->
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <!-- boutons -->
                    <h2 class="kith2">Boutons :</h2>
                    <button type="button" class="button1">Bouton 1</button><br>
                    <button type="button" class="button2">Bouton 2</button>
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- BOOTSTRAP -->
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Bootstrap :</h2>
                    
                    <h3 class="kith3">Navbar :</h3>
                    
                    <!-- navbar -->
                    
                    <nav class="navbar navbar-default"> <!-- pour la fixer en haut : (class) navbar-fixed-top -->
                        <div class="container">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <!-- catégories de la navbar -->

                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav">
                                    <li><a href="#1">1</a></li>
                                    <li><a href="#2">2</a></li>
                                    <li><a href="#3">3</a></li>
                                    <li><a href="#4">4</a></li>
                                    <li><a href="#5">5</a></li>
                                    <li><a href="#6">6</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- glyphicon -->
        
                    <h3 class="kith3">Glyphicon :</h3>
                    
                    <span class="glyphicon glyphicon-calendar"></span>
                    <span class="glyphicon glyphicon-map-marker"></span>
                    <span class="glyphicon glyphicon-education"></span>
                    <span class="glyphicon glyphicon-time"></span>
                    <span class="glyphicon glyphicon-wrench"></span>
                    <span class="glyphicon glyphicon-download-alt"></span>
                    <span class="glyphicon glyphicon-chevron-up"></span>
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="glyphicon glyphicon-chevron-right"></span>

                    <!-- responsive -->

                    <h3 class="kith3">Responsive :</h3>

                    <div class="container"><!-- 3 ordi, 2 tablette, 1 telephone-->
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <p style="text-align:center;">Responsive 1</p>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <p style="text-align:center;">Responsive 2</p>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <p style="text-align:center;">Responsive 3</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- bouton -->
        
                    <h3 class="kith3">Bouton bootstrap :</h3>
                    
                    <button type="button" class="btn btn-primary">Bouton bootstrap</button>

                    <!-- formulaire -->

                    <h3 class="kith3">Formulaire :</h3>

                    <!-- input -->

                    <label for="Input" class="labelFormulaire">Input<span style="color:red;"> *</span></label>
                    <input type="text" id="Input" name="Input" class="form-control" placeholder="">

                    <!-- textarea -->

                    <label for="textarea" class="labelFormulaire">Textarea<span style="color:red;"> *</span></label>
                    <textarea id="textarea" name="textarea" class="form-control" placeholder="" rows="4"></textarea>
                    
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- ANIMATION / JQUERY -->
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Animation (jQuery) :</h2>
        
                    <!-- icone -->
                    
                    <footer id="1.1">
                        <a href="#1"> 
                            <span class="glyphicon glyphicon-chevron-up"></span>
                        </a>
                    </footer>
                    
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- PROJETS -->
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Projets</h2>

                    <!-- image et modal -->
                    
                    <h3 class="kith3">Image et modal :</h3>
       
                    <!-- exemple -->
                    
                    <section id="projets">
                        <div class="container">
                            <div class="row">
                                <div class='col-lg-6 col-md-12 col-sm-12'>
                                    
                                    <!-- image -->

                                    <a class='thumbnail' href='#' data-toggle='modal' data-target='#modal'>
                                        <img src='images/CV_Pierre_Dupont.png' class='imageprojet' alt='image_projet'>
                                    </a>

                                    <!-- modal -->

                                    <div class='modal fade' id='modal'> 
                                        <div class='modal-dialog'>
                                            <div class='modal-content'>
                                                <div class='modal-header'>
                                                    <button type='button' class='close' data-dismiss='modal'>x</button>
                                                    <h5 class='modal-title'>Titre du projet</h5>
                                                </div>
                                                <div class='modal-body'>
                                                    <p>Vous allez être redirigé vers une autre page, voulez-vous continuer ?</p>
                                                </div>
                                                <div class='modal-footer'>
                                                    <a href='#' class='buttons'>Continuer</a>
                                                    <button type='button' class='buttons' data-dismiss='modal'>Fermer</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </section>
                    
                    <!-- image et modal -->
                    
                    <h3 class="kith3">Fiche projet :</h3>
                    
                    <div class="container">
                        <div class="row">

                            <!-- block description -->
                            
                            <div class='col-lg-6 col-md-6 col-sm-12'>
                                <div class='projet-block'>
                                    <h3>Titre</h3>
                                    <h4>Contexte : </h4>
                                    <div class='col-lg-12 col-md-12 col-sm-12'>
                                        <p class='pDetailProjet1'>description</p><br>
                                    </div>
                                    <h4>Détails :</h4>
                                    <div class='col-lg-6 col-md-6 col-sm-6'>
                                        <p class='pDetailProjet'><span class='glyphicon glyphicon-calendar'></span>&emsp;date</p>
                                        <p class='pDetailProjet'><span class='glyphicon glyphicon-time'></span>&emsp;temps</p>
                                    </div>
                                    <div class='col-lg-6 col-md-6 col-sm-6'>
                                        <p class='pDetailProjet'><span class='glyphicon glyphicon-education'></span>&emsp;cadre</p>
                                        <p class='pDetailProjet'><span class='glyphicon glyphicon-wrench'></span>&emsp;stack_technique</p>
                                    </div>
                                    <a href='' class='buttonpro'><span class='glyphicon glyphicon-download-alt'></span>&emsp;Télécharger le projet (zip)</a>
                                </div>
                            </div>
                            
                            <!-- image -->

                            <div class='col-lg-6 col-md-6 col-sm-12'>
                                <br> <br>
                                <a class='thumbnail'>
                                    <img src="images/CV_Pierre_Dupont.png" class="imageprojet" alt="titre">
                                </a>
                            </div>
                            
                        </div>
                    </div>
                    
                    <!-- carousel -->
                    
                    <h3 class="kith3">Carousel :</h3>

                    <div class="container">        
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div id="carousel" class="carousel slide" data-ride="carousel" style="max-width:800px;">
                                    <ul class="carousel-indicators">
                                        <li data-target="#carousel" data-slide-to="0" class="active"></li>
                                        <li data-target="#carousel" data-slide-to="1"></li>
                                        <li data-target="#carousel" data-slide-to="2"></li>
                                        <li data-target="#carousel" data-slide-to="3"></li>
                                    </ul>    

                                    <!-- création des éléments du carousel -->

                                    <div class="carousel-inner" role="listbox">
                                        <div class="item active">
                                            <img src="images/CV_Pierre_Dupont_1.png">
                                        </div> 
                                        <div class="item">   
                                            <img src="images/CV_Pierre_Dupont_2.png">
                                        </div>
                                        <div class="item">   
                                            <img src="images/CV_Pierre_Dupont_3.png">
                                        </div>
                                        <div class="item">   
                                            <img src="images/CV_Pierre_Dupont_4.png">
                                        </div>
                                    </div>    

                                    <!-- création des boutons du carousel -->

                                    <a href="#carousel" class="left carousel-control" role="button" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>
                                    </a>
                                    <a href="#carousel" class="right carousel-control" role="button" data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>
                                    </a>    
                                </div> 
                            </div>   
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        
        
        
       
        <!-- TIMELINE --> 
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Timeline :</h2>
        
                    <!-- bouton affichant les compétences en fonction de l'année scolaire -->

                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <button type="button" class="btn btn-primary" id="a2021" >Consulter l'année 2021-2022</button>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <button type="button" class="btn btn-primary" id="a2022">Consulter l'année 2022-2023</button>
                            </div>
                        </div>

                        <!-- timeline année 2022-2023-->

                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <ul class="timeline" id="timeline2">

                                    <!-- timeline date 2022-->

                                    <li class="timeline-inverted">
                                        <div class="timeline-badge info"></div>
                                        <div class="timeline-panel">
                                            <div class="timeline-heading">
                                                <h4 class="timeline-title"><i class="glyphicon glyphicon-calendar" style="color: #008"></i>&nbsp;Date</h4>
                                            </div>
                                            <div class="timeline-body">
                                                <p class="pProjet">Stack technique :</p>
                                                <p class="pProjet">Projet encadré :</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>                   
                        </div>

                        <!-- timeline année 2021-2022 -->

                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <ul class="timeline" id="timeline">

                                    <!-- timeline date 2021-->

                                    <li>
                                        <div class="timeline-badge info"></div>
                                        <div class="timeline-panel">
                                            <div class="timeline-heading">
                                                <h4 class="timeline-title"><i class="glyphicon glyphicon-calendar" style="color: #008"></i>&nbsp;Date</h4>
                                            </div>
                                            <div class="timeline-body">
                                                <p class="pProjet">Stack technique :</p>
                                                <p class="pProjet">Projet encadré :</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>                   
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- PARCOURS SCOLAIRE --> 
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Parcours scolaire :</h2>

                    <!-- exemple -->

                    <div class="container">
                        <div class="row">
                            <div class="col-xs-10 col-xs-offset-1 col-sm-10 col-sm-offset-2 col-md-6 col-md-offset-0 col-lg-5">
                                <article style="background-image: url(images/st-vincent.jpg)">
                                    <div class="overlay1">
                                        <h4>Nom école</h4>
                                        <p class="lieuScolaire0"><span class="glyphicon glyphicon-map-marker"> Lieu</span></p>
                                        <p class="dateScolaire0"><span class="glyphicon glyphicon-calendar"> Date</span></p>
                                        <p class="dyplomeScolaire0"><span class="glyphicon glyphicon-education"> Diplôme</span></p>
                                        <a href="" class="buttons">Lien site</a> <!--target="_blank"-->
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        
        <!-- CONNEXION --> 

        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    
                    <h2 class="kith2">Connexion :</h2>

                    <!-- formulaire -->
                    
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="thumbnail">
            
                            <form class="form" method="post" name="login">
                  
                                <!-- input -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group"><br>
                                        <label for="" class="labelFormulaireProjet">Input :</label>
                                        <input type="text" id="" name="" placeholder="" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="labelFormulaireProjet">Input :</label>
                                        <input type="text" id="" name="" placeholder="" class="form-control">
                                    </div>
                                </div>
                        
                                <!-- bouton connexion -->

                                <div class="form-actions">
                                    <input type="submit" value="Connexion " name="submit" class="btnajouter2">
                                </div>
                                
                            </form>
                        </div>
                    </div>              
        
                </div>
            </div>
        </div>
        
    </body>
</html>