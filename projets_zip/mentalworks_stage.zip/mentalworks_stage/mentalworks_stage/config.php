<?php

/* déclaration des variables de connexion à la base de donnée */

$dbHost = "localhost";
$dbName = "mentalworks";
$dbUser = "root";
$dbUserPassword = "root";
$connection = null;

?>