<?php

/* déclaration des variables de connexion à la base de donnée */

$dbHost = "localhost";
$dbName = "exercice";
$dbUser = "root";
$dbUserPassword = "root";
$connection = null;

?>