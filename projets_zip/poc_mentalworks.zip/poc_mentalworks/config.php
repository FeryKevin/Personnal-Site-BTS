<?php

/* déclaration des variables de connexion à la base de donnée */

$dbHost = "localhost";
$dbName = "poc_mentalworks";
$dbUser = "root";
$dbUserPassword = "root";
$connection = null;

?>