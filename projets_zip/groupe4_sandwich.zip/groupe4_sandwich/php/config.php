<?php 

    #Lien de la BDD 
    $dbHost = "localhost";

    #Nom de la BDD
    $dbName = "lyceestvincent_groupe4";

    #User login
    $dbUser = 'root';

    #User password
    $dbUserPw = "root";

?>