# Projet_PHP

Un site internet qui permet de gérer des différents projets,  
Le projet introduit au php objet et ses principes plus poussés
