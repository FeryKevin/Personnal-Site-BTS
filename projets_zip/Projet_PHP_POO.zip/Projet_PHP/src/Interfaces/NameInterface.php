<?php

namespace App\Interfaces;

interface nameInterface{
    public function getName(): string;
    public function setName(string $newName): void; 
}