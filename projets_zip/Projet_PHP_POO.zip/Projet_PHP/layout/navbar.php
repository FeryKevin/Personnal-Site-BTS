<div id='navbar'>
    <div>
        <img src="public\img\logo.png" class="navbar-brand">
        <span class="glyphicon glyphicon-menu-hamburger" style="color: #fff" id="gly1"></span>          
    </div>
</div>