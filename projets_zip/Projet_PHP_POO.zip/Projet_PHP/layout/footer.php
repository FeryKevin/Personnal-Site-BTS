<footer>
    <h4>FERY Kevin - AMBROISE Pierre - © 2022</h4>
</footer>