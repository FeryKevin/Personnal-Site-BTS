<div id='menu'> 
    <ul id="m1"><a href="index.php">&emsp;<span class="glyphicon glyphicon-home"></span>&emsp;TABLEAU DE BORD</a></ul>
    <ul id="m2"><a href="project/all">&emsp;<span class="glyphicon glyphicon-user"></span>&emsp;PROJETS</a></ul>
    <ul id="m3"><a href="customer/all">&emsp;<span class="glyphicon glyphicon-inbox"></span>&emsp;CLIENTS</a></ul>
    <ul id="m4"><a href="host/all">&emsp;<span class="glyphicon glyphicon-check"></span>&emsp;HÉBERGEURS</a></ul>
</div>