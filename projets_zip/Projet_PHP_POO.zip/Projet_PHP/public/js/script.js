$(document).ready(function(){ 
    $("#gly1").click(function(){
        $("#menu").toggle();
    });
});